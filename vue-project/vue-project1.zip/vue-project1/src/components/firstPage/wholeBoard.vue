<template>
    <div class="headBar">
        <nav>
            <div class="logo">
                <a href="#">WFU Problem</a>
            </div>
            <div class="menu">
                <ul>
                    <li class="navlists">
                        <a class="navtag" href="#">Groups</a>
                        <ul class="droplist">
                            <li class="dropContents"><a href="#">Droplist 1</a></li>
                            <li class="dropContents"><a href="#">Droplist 2</a></li>
                            <li class="dropContents"><a href="#">Droplist 3</a></li>
                            <li class="dropContents"><a href="#">Droplist 4</a></li>
                            <li class="dropContents"><a href="#">Droplist 5</a></li>
                        </ul>
                    </li>
                    <li class="navlists"><a class="navtag" href="#">About</a></li>
                    <li class="navlists"><a class="navtag" href="#">Services</a></li>
                    <li class="navlists"><a class="navtag" href="#">Contact</a></li>
                </ul>
            </div>
        </nav>
    </div>
</template>
  
<style scoped>
* {
    margin: 0;
    padding: 0;
    text-decoration: none;
    list-style: none;
}

.headBar {
    background-color: black;
    box-shadow: 0px 1px 3px #666;
    height: 70px;
}

nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    margin: 0 auto;
    max-width: 1500px;
    padding: 0 20px;
}

.logo a {
    font-size: 28px;
    font-weight: bold;
    color: white;
}

.menu ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding-left: 50px;
}

.menu .navlists {
    margin-left: 10px;
    position: relative;
    display: inline-block;
}

.menu .navlists:first-child {
    margin-left: 0;
}

.menu .navlists .navtag {
    display: block;
    font-size: 24px;
    font-weight: bold;
    color: white;
    text-decoration: none;
    padding: 10px;
    transition: color 0.3s ease;
}

.menu .navlists:hover .navtag {
    color: #777777;
}

.menu ul li:hover>ul {
    display: block;
}

.menu ul li:hover::after ul{
    display: block;
    height: 600px;
}

.menu ul li ul {
    display: none;
    position: absolute;
    top: 57px;
    left: -60px; 
    background-color: #333;
    padding: 0;
    width: 220px;
    border-radius: 5px;
    box-shadow: 0px 3px 3px rgba(0, 0, 0, 0.2);
    z-index: 999;
}

.menu ul li ul li {
    display: block;
}

.menu ul li ul li a {
    padding: 20px 15px;
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    text-decoration: none;
    display: block;
}

.menu ul li ul li a:hover {
    background-color: #555;
    color: #fff;
}

/* Added the following style for the dropdown menu */
.menu ul li ul:hover {
    display: block;
}
</style>
