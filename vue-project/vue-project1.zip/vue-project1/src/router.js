import { createRouter, createWebHashHistory } from 'vue-router'
import mainPage from './components/mainPage.vue'
import signUp from './components/signUp.vue'
import wholeBoard from './components/firstPage/wholeBoard.vue'

const routes = [
  {
    path: '/',
    name: 'MainPage',
    component: mainPage
  },
  {
    path: '/signup',
    name: 'Signup',
    component: signUp
  },
  {
    path: '/wholeBoard',
    name: 'wholeBoard',
    component: wholeBoard
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
